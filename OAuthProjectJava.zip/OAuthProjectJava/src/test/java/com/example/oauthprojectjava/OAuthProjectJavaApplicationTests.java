package com.example.oauthprojectjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OAuthProjectJavaApplicationTests {

    @Test
    void contextLoads() {
    }

}
