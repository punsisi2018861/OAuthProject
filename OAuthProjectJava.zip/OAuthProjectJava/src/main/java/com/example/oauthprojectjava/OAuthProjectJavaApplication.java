package com.example.oauthprojectjava;

import com.mastercard.developer.oauth.OAuth;
import com.mastercard.developer.signers.HttpsUrlConnectionSigner;
import com.mastercard.developer.utils.AuthenticationUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.net.ssl.HttpsURLConnection;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

@SpringBootApplication
public class OAuthProjectJavaApplication {

    public static void main(String[] args) throws UnrecoverableKeyException, CertificateException, IOException, KeyStoreException, NoSuchAlgorithmException {
        SpringApplication.run(OAuthProjectJavaApplication.class, args);
        System.out.println("OAuthHeader::::"+getOAuthHeader());
    }

    public static String getOAuthHeader() throws UnrecoverableKeyException, CertificateException, IOException, KeyStoreException, NoSuchAlgorithmException {

       String consumerKey = "COGvaX3czfzNRvQq0rS9Fkqb4FQwzdDRPjWdghR3635ae04f!81d1d19015384292ab4c6502d2c359ef0000000000000000";
        URI uri = URI.create("https://sandbox.api.mastercard.com/billpayAPI/v1/isRoutingValid");
        String method = "POST";
        String payload = "{\"BillPayAccountValidation\": {\"RppsId\": \"99887761\",\"BillerId\": \"9998887771\",\"AccountNumber\": \"1234567890\",\"TransactionAmount\": \"250.00\",\"CustomerIdentifier1\": \"\",\"CustomerIdentifier2\": \"\",\"CustomerIdentifier3\": \"\",\"CustomerIdentifier4\": \"\",\"ResponseString\": \"Successful\"}}";
        Charset charset = StandardCharsets.UTF_8;
        String authHeader = OAuth.getAuthorizationHeader(uri, method, payload, charset, consumerKey, getPrivateKey());
        return authHeader;
    }

    public static PrivateKey getPrivateKey() throws UnrecoverableKeyException, CertificateException, IOException, KeyStoreException, NoSuchAlgorithmException {
        PrivateKey signingKey = AuthenticationUtils.loadSigningKey(
                "src/main/resources/securityKeys/TestOAuthProject-sandbox.p12",
                "keyalias",
                "keystorepassword");
        return signingKey;
    }

    public static void signIn() throws IOException, UnrecoverableKeyException, CertificateException, KeyStoreException, NoSuchAlgorithmException {

        String consumerKey = "COGvaX3czfzNRvQq0rS9Fkqb4FQwzdDRPjWdghR3635ae04f!81d1d19015384292ab4c6502d2c359ef0000000000000000";

        Charset charset = StandardCharsets.UTF_8;
        URL url = new URL("https://sandbox.api.mastercard.com/service");
        String payload = "{\"foo\":\"bar\"}";

        HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json; charset=" + charset.name());

        HttpsUrlConnectionSigner signer = new HttpsUrlConnectionSigner(charset, consumerKey, getPrivateKey());
        signer.sign(con, payload);
    }

}


